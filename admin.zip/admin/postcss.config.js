export default {
  plugins: [],
};
